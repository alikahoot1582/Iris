import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score

# Title
st.title("🌸 Iris Dataset Explorer & Classifier")

# Load Data
@st.cache_data
def load_data():
    df = pd.read_csv("Iris.csv")
    return df

df = load_data()

# Sidebar Navigation
st.sidebar.title("Navigation")
page = st.sidebar.radio("Go to", ["Dataset Overview", "Visualizations", "Model Trainer"])

# Page 1: Dataset Overview
if page == "Dataset Overview":
    st.header("📊 Dataset Overview")
    st.write("Here's a quick look at the Iris dataset:")
    st.dataframe(df.head())

    st.subheader("Summary Statistics")
    st.write(df.describe())

    st.subheader("Class Distribution")
    st.bar_chart(df["Species"].value_counts())

# Page 2: Visualizations
elif page == "Visualizations":
    st.header("📈 Visualizations")

    st.subheader("Pairplot")
    fig = sns.pairplot(df, hue="Species")
    st.pyplot(fig)

    st.subheader("Correlation Heatmap")
    fig2, ax = plt.subplots()
    sns.heatmap(df.drop("Id", axis=1).corr(), annot=True, cmap="coolwarm", ax=ax)
    st.pyplot(fig2)

# Page 3: Model Trainer
elif page == "Model Trainer":
    st.header("🤖 Train a Random Forest Classifier")

    # Feature selection
    st.subheader("Select Features")
    features = df.columns[1:-1]  # Exclude Id and Species
    selected_features = st.multiselect("Choose features", features, default=list(features))

    if selected_features:
        X = df[selected_features]
        y = df["Species"]

        # Train-test split
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

        # Model training
        model = RandomForestClassifier()
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)

        # Results
        st.subheader("Model Performance")
        st.write(f"Accuracy: {accuracy_score(y_test, y_pred):.2f}")
        st.text("Classification Report:")
        st.text(classification_report(y_test, y_pred))
    else:
        st.warning("Please select at least one feature to train the model.")
